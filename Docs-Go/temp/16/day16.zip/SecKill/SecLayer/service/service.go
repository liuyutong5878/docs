package service

func Run() (err error) {

	//起处理线程
	err = RunProcess()
	return
}
